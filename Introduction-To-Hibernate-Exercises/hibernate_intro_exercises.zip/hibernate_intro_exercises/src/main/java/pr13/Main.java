package pr13;

import entities.Employee;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class Main {

    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";
    private static final String EMPLOYEE_TABLE_NAME = "Employee";

    public static void main(String[] args) throws IOException {
        String firstNamePattern = null;
        try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(System.in));){
            firstNamePattern = buffReader.readLine();
        }

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em = emf.createEntityManager();

        Query query = em.createQuery("SELECT e FROM " + EMPLOYEE_TABLE_NAME + " AS e " +
                "WHERE e.firstName LIKE " + "\'" + firstNamePattern + '%' + "\'");
        List<Employee> employees = query.getResultList();

        em.close();
        emf.close();

        StringBuilder employeesInfo = new StringBuilder();
        for (Employee employee : employees) {
            employeesInfo.append(String.format("%s %s - %s - ($%.2f)%n",
                    employee.getFirstName(),
                    employee.getLastName(),
                    employee.getJobTitle(),
                    employee.getSalary()));
        }

        System.out.println(employeesInfo);
    }
}
