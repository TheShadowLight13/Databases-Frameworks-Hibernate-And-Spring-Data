package pr12;

import entities.Address;
import entities.Employee;
import entities.Town;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class Main {

    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";
    private static final String TOWN_TABLE_NAME = "Town";
    private static final String ADDRESS_TABLE_NAME = "Address";

    public static void main(String[] args) throws IOException {
        String targetTownName = null;
        try (BufferedReader buffReader = new BufferedReader(new InputStreamReader(System.in))){
            targetTownName = "\'" + buffReader.readLine() + "\'";
        }

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em = emf.createEntityManager();

        Query query = em.createQuery("SELECT e FROM " + TOWN_TABLE_NAME + " AS e" +
                " WHERE e.name = " + targetTownName);
        Town targetTown = (Town) query.getSingleResult();

        query = em.createQuery("SELECT a FROM " + ADDRESS_TABLE_NAME + " AS a" +
                " WHERE a.town.id = (:id)");
        query.setParameter("id", targetTown.getId());
        List<Address> addresses = query.getResultList();

        em.getTransaction().begin();

        for (Address address : addresses) {
            for (Employee employee : address.getEmployees()) {
                employee.setAddress(null);
            }

            em.remove(address);
        }

        em.remove(targetTown);
        em.getTransaction().commit();

        em.close();
        emf.close();

        System.out.printf("%d addresses in %s were deleted%n",
                addresses.size(),
                targetTownName);
    }
}
