package pr11;

import entities.Employee;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";
    private static final BigDecimal INCREASE_PERCENT_STRING = new BigDecimal("0.12");

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);

        EntityManager em = emf.createEntityManager();

        List<String> targetDepartmentNames = new ArrayList<>();
        Collections.addAll(targetDepartmentNames,
                "Engineering", "Tool Design", "Marketing", "Information Services ");

        Query query = em.createQuery("SELECT e FROM Employee AS e" +
                " INNER JOIN e.department AS d WHERE d.name IN (:depts)");
        query.setParameter("depts", targetDepartmentNames);
        List<Employee> employees = query.getResultList();

        em.getTransaction().begin();

        for (Employee employee : employees) {
            BigDecimal salary = employee.getSalary();
            BigDecimal newSalary = employee.getSalary()
                    .add(salary.multiply(INCREASE_PERCENT_STRING));
            employee.setSalary(newSalary);
        }

        em.getTransaction().commit();

        for (Employee employee : employees) {
            System.out.printf("%s %s ($%.2f)%n",
                    employee.getFirstName(),
                    employee.getLastName(),
                    employee.getSalary());
        }

        em.close();
        emf.close();
    }
}
