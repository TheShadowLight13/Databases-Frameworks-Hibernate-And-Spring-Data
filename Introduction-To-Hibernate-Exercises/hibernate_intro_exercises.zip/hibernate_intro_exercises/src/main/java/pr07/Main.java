package pr07;

import entities.Address;
import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main {

    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";
    private static final String EMPLOYEE_TABLE_NAME = "Employee";
    private static final String ADDRESS_TEXT = "Vitoshka 15";
    private static final String LAST_NAME = "'Nakov'";

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);

        EntityManager em = emf.createEntityManager();

        Address address = new Address();
        address.setText(ADDRESS_TEXT);

        Query query = em
                .createQuery("SELECT e FROM " + EMPLOYEE_TABLE_NAME + " AS e WHERE e.lastName = " + LAST_NAME);
        Employee employee = (Employee) query.getSingleResult();

        em.getTransaction().begin();

        employee.setAddress(address);
        em.persist(address);

        em.getTransaction().commit();

        System.out.println(employee.getAddress().getText());

        em.close();
        emf.close();
    }
}
