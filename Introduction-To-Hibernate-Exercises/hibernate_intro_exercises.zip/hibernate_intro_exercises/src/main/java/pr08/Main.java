package pr08;

import entities.Address;
import entities.Department;
import entities.Employee;
import entities.Project;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;
import java.util.Set;

public class Main {

    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";
    private static final String ADDRESS_TABLE_NAME = "Address";
    private static final String EMPLOYEE_TABLE_NAME = "Employee";
    private static final String PROJECT_TABLE_NAME = "Project";
    private static final String DEPARTMENT_TABLE_NAME = "Department";
    private static final int MAX_ADDRESSES_COUNT = 10;
    private static final int TARGET_EMPLOYEE_ID = 13;

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);

        EntityManager em = emf.createEntityManager();

        // Part 1
        Query query1 = em.createQuery("SELECT DISTINCT a FROM " + ADDRESS_TABLE_NAME + " AS a"
                + " ORDER BY a.employees.size DESC, a.town.name ASC");
        List<Address> addresses = query1.setMaxResults(MAX_ADDRESSES_COUNT).getResultList();

        for (Address address : addresses) {
            System.out.printf("%s, %s - %d employees%n",
                    address.getText(),
                    address.getTown().getName(),
                    address.getEmployees().size());
        }

        // Part 2
        Employee employee = em.find(Employee.class, TARGET_EMPLOYEE_ID);
        System.out.printf("%s %s, %s%n",
                employee.getFirstName(),
                employee.getLastName(),
                employee.getJobTitle());
        employee.getProjects()
                .stream().sorted((p1, p2) -> p1.getName().compareTo(p2.getName()))
                .forEach(p -> System.out.println(p.getName()));

        // Part 3
        List<Integer> projectIds = em
                .createQuery("SELECT p.id FROM " + PROJECT_TABLE_NAME + " AS p " +
                        "WHERE DATE_FORMAT(p.startDate, '%Y') BETWEEN 2001 AND 2003")
                .getResultList();
        Query query2 = em.createQuery("SELECT e FROM " + EMPLOYEE_TABLE_NAME + " AS e " +
                "INNER JOIN e.projects AS p " + "WHERE p.id IN (:ids)");
        query2.setParameter("ids", projectIds);

        List<Employee> employees = query2.getResultList();

        for (Employee employee1 : employees) {
            System.out.printf("%s %s - Manager: %s%n",
                    employee1.getFirstName(),
                    employee1.getLastName(),
                    employee.getManager().getFirstName());

            for (Project project : employee1.getProjects()) {
                System.out.printf("%s %s - %s%n",
                        project.getName(),
                        project.getStartDate(),
                        project.getEndDate());
            }
        }

        // Part 4
        Query query3 = em.createQuery("SELECT d FROM " + DEPARTMENT_TABLE_NAME + " AS d" +
                " WHERE d.employees.size > 5 ORDER BY d.employees.size ASC");
        List<Department> departments = query3.getResultList();

        System.out.println(departments.size());
        for (Department department : departments) {
            System.out.printf("--%s - Manager: %s, Employees: %d%n",
                    department.getName(),
                    department.getManager().getLastName(),
                    department.getEmployees().size());

            Set<Employee> employeesInDepartment = department.getEmployees();
            StringBuilder employeesInfo = new StringBuilder();

            for (Employee employeeInDepartment : employeesInDepartment) {
                employeesInfo.append(String.format("%s %s HireDate: %s %s%n",
                        employeeInDepartment.getFirstName(),
                        employeeInDepartment.getLastName(),
                        employeeInDepartment.getHireDate(),
                        employeeInDepartment.getJobTitle()));
            }

            System.out.print(employeesInfo);
        }

        em.close();
        emf.close();
    }
}
