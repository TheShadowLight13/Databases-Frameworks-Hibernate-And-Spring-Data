package pr14;

import entities.Department;
import entities.Employee;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;

public class Main {

    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";
    private static final String DEPARTMENT_TABLE_NAME = "Department";

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager em = emf.createEntityManager();

        Query query = em.createQuery("SELECT d FROM " + DEPARTMENT_TABLE_NAME + " AS d" +
                " INNER JOIN d.employees AS e GROUP BY d " +
                "HAVING MAX(e.salary) NOT BETWEEN 30000 AND 70000");
        List<Department> departments = query.getResultList();

        Comparator<Employee> salaryComparator = (e1, e2) ->
                e1.getSalary().compareTo(e2.getSalary());

        for (Department department : departments) {
            BigDecimal maxSalary = department.getEmployees()
                    .stream().max(salaryComparator).map(Employee::getSalary).get();

            System.out.printf("%s - %.2f%n",
                    department.getName(),
                    maxSalary);
        }

        em.close();
        emf.close();
    }
}
