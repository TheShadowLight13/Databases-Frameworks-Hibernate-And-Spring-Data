package pr02;

import entities.Address;
import entities.Department;
import entities.Employee;
import entities.Town;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.math.BigDecimal;
import java.sql.Timestamp;

public class Main {

    private static final String DEPARTMENT_NAME = "Training";
    private static final String TOWN_NAME = "Burgas";
    private static final String ADDRESS_ONE_TEXT = "Septemvri 23";
    private static final String ADDRESS_TWO_TEXT = "Vasil Levski 57";
    private static final String ADDRESS_THREE_TEXT = "Hristo Botev 1";
    private static final String EMPLOYEE_ONE_FIRST_NAME = "Ivan";
    private static final String EMPLOYEE_ONE_LAST_NAME = "Ivanov";
    private static final String EMPLOYEE_ONE_SALARY = "300";
    private static final String EMPLOYEE_ONE_JOB_TITLE = "Production Technician";
    private static final String EMPLOYEE_TWO_FIRST_NAME = "Dimitar";
    private static final String EMPLOYEE_TWO_LAST_NAME = "Dimitrov";
    private static final String EMPLOYEE_TWO_JOB_TITLE = "Tool Designer";
    private static final String EMPLOYEE_TWO_SALARY = "700";
    private static final String EMPLOYEE_THREE_FIRST_NAME = "Vasil";
    private static final String EMPLOYEE_THREE_LAST_NAME = "Vasilev";
    private static final String EMPLOYEE_THREE_MIDDLE_NAME = "Vasilev";
    private static final String EMPLOYEE_THREE_JOB_TITLE = "Design Engineer";
    private static final String EMPLOYEE_THREE_SALARY = "700";
    private static final String EMPLOYEE_FOUR_FIRST_NAME = "Hristo";
    private static final String EMPLOYEE_FOUR_LAST_NAME = "Vasilev";
    private static final String EMPLOYEE_FOUR_JOB_TITLE = "Tool Designer";
    private static final String EMPLOYEE_FOUR_SALARY = "1000";
    private static final String EMPLOYEE_FIVE_FIRST_NAME = "Spasina";
    private static final String EMPLOYEE_FIVE_LAST_NAME = "Dimitrova";
    private static final String EMPLOYEE_FIVE_JOB_TITLE = "Software Engineer";
    private static final String EMPLOYEE_FIVE_SALARY = "3000";
    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";

    public static void main(String[] args) {
        EntityManagerFactory entityManagerFactory =
                Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        Employee manager = entityManager.find(Employee.class, 4);
        Department training = new Department(DEPARTMENT_NAME, manager);

        Town burgas = new Town(TOWN_NAME);

        Address addressOne = new Address(ADDRESS_ONE_TEXT, burgas);
        Address addressTwo = new Address(ADDRESS_TWO_TEXT, burgas);
        Address addressThree = new Address(ADDRESS_THREE_TEXT, burgas);

        Employee employeeOne = new Employee(EMPLOYEE_ONE_FIRST_NAME, EMPLOYEE_ONE_LAST_NAME,
                null, EMPLOYEE_ONE_JOB_TITLE, training, manager,
                new Timestamp(System.currentTimeMillis()), new BigDecimal(EMPLOYEE_ONE_SALARY),
                addressOne);

        Employee employeeTwo = new Employee(EMPLOYEE_TWO_FIRST_NAME, EMPLOYEE_TWO_LAST_NAME,
                null, EMPLOYEE_TWO_JOB_TITLE, training, manager,
                new Timestamp(System.currentTimeMillis()), new BigDecimal(EMPLOYEE_TWO_SALARY),
                addressTwo);

        Employee employeeThree = new Employee(EMPLOYEE_THREE_FIRST_NAME, EMPLOYEE_THREE_LAST_NAME,
                EMPLOYEE_THREE_MIDDLE_NAME, EMPLOYEE_THREE_JOB_TITLE, training, manager,
                new Timestamp(System.currentTimeMillis()), new BigDecimal(EMPLOYEE_THREE_SALARY),
                addressThree);

        Employee employeeFour = new Employee(EMPLOYEE_FOUR_FIRST_NAME, EMPLOYEE_FOUR_LAST_NAME,
                null, EMPLOYEE_FOUR_JOB_TITLE, training, manager,
                new Timestamp(System.currentTimeMillis()), new BigDecimal(EMPLOYEE_FOUR_SALARY),
                addressTwo);

        Employee employeeFive = new Employee(EMPLOYEE_FIVE_FIRST_NAME, EMPLOYEE_FIVE_LAST_NAME,
                null, EMPLOYEE_FIVE_JOB_TITLE, training, manager,
                new Timestamp(System.currentTimeMillis()), new BigDecimal(EMPLOYEE_FIVE_SALARY),
                addressThree);

        entityManager.getTransaction().begin();

        entityManager.persist(training);
        entityManager.persist(burgas);
        entityManager.persist(addressOne);
        entityManager.persist(addressTwo);
        entityManager.persist(addressThree);
        entityManager.persist(employeeOne);
        entityManager.persist(employeeTwo);
        entityManager.persist(employeeThree);
        entityManager.persist(employeeFour);
        entityManager.persist(employeeFive);

        entityManager.getTransaction().commit();
        entityManager.close();
        entityManagerFactory.close();
    }
}
