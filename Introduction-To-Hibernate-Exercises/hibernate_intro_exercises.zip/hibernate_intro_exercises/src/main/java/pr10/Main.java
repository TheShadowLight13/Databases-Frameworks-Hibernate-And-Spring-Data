package pr10;

import entities.Project;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;

public class Main {

    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";
    private static final String PROJECT_TABLE_NAME = "Project";
    private static final int MAX_PROJECTS_COUNT = 10;

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);

        EntityManager em = emf.createEntityManager();

        Query query1 = em.createQuery("SELECT p FROM " + PROJECT_TABLE_NAME + " AS p" +
                " ORDER BY p.startDate DESC").setMaxResults(MAX_PROJECTS_COUNT);

        List<Project> lastStartedProjects = query1.getResultList();
        Query query2 = em.createQuery("SELECT lp FROM Project AS lp " +
                "WHERE lp IN (:lsp) ORDER BY lp.name ASC");
        query2.setParameter("lsp", lastStartedProjects);

        List<Project> sortedLastStartedProjects = query2.getResultList();
        for (Project project : sortedLastStartedProjects) {
            System.out.printf("Name: %s, Description: %s, StartDate: %s, EndDate: %s%n",
                    project.getName(),
                    project.getDescription(),
                    project.getStartDate(),
                    project.getEndDate());
        }

        em.close();
        emf.close();
    }
}
