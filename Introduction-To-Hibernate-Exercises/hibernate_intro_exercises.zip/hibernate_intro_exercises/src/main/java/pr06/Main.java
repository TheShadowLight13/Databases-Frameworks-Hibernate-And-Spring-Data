package pr06;

import entities.Employee;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.util.List;

public class Main {

    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";
    private static final String EMPLOYEE_TABLE_NAME = "Employee";
    private static final String TARGET_DEPARTMENT_NAME = "'Research and Development'";
    private static final int TARGET_SALARY = 50000;

    public static void main(String[] args) {

        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);

        EntityManager em = emf.createEntityManager();

        Query query = em.createQuery("SELECT e.firstName FROM " + EMPLOYEE_TABLE_NAME
                + " AS e WHERE e.salary > " + TARGET_SALARY);
        List<String> employeeNames = query.getResultList();

        for (String employeeName : employeeNames) {
            System.out.println(employeeName);
        }

        Query query1 = em.createQuery("SELECT e " +
                "FROM " + EMPLOYEE_TABLE_NAME + " AS e " +
                "INNER JOIN " + "e.department AS d WHERE d.name = " + TARGET_DEPARTMENT_NAME
        + " ORDER BY e.salary ASC, e.firstName DESC");
        List<Employee> employees = query1.getResultList();

        for (Employee employee : employees) {
            System.out.printf("%s %s from %s - $%.2f%n",
                    employee.getFirstName(),
                    employee.getLastName(),
                    employee.getDepartment().getName(),
                    employee.getSalary());
        }

        em.close();
        emf.close();
    }
}
