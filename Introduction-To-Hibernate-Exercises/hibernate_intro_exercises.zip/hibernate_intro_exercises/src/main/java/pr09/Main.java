package pr09;

import entities.Town;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.LockModeType;
import javax.persistence.Persistence;

public class Main {

    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);

        EntityManager em1 = emf.createEntityManager();
        EntityManager em2 = emf.createEntityManager();

        Town town1 = em1.find(Town.class, 1);
        Town town2 = em2.find(Town.class, 1);

        em1.getTransaction().begin();

        em1.lock(town1, LockModeType.PESSIMISTIC_WRITE);
        town1.setName(town1.getName().toLowerCase());

        em1.getTransaction().commit();

        em2.getTransaction().begin();

        em2.lock(town2, LockModeType.PESSIMISTIC_WRITE);
        town2.setName(town2.getName().toUpperCase());

        em2.getTransaction().commit();

        em1.close();
        em2.close();
        emf.close();
    }
}
