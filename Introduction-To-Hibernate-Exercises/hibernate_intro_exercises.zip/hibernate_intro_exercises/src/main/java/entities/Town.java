package entities;

import javax.persistence.*;

@Entity
@Table(name = "towns")
public class Town {

    private Integer id;

    private String name;

    public Town(String name) {
        this.setName(name);
    }

    public Town() {}

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "town_id")
    public Integer getId() {
        return this.id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "name")
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
