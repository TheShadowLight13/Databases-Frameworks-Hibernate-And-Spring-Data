package pr03;

import entities.Town;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;

public class Main {

    private static final String PERSISTENCE_UNIT_NAME = "soft_uni";
    private static final String TOWN_TABLE_NAME = "Town";
    private static final int TARGET_NAME_LEN = 5;

    public static void main(String[] args) {
        EntityManagerFactory entityManagerFactory =
                Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
        EntityManager entityManager = entityManagerFactory.createEntityManager();

        List<Town> allTowns =  entityManager
                .createQuery("SELECT e FROM " + TOWN_TABLE_NAME +  " AS e").getResultList();

        entityManager.getTransaction().begin();

        for (Town town : allTowns) {
            String townName = town.getName();
            if (townName.length() > TARGET_NAME_LEN) {
                entityManager.detach(town);
            }else {
                town.setName(townName.toLowerCase());
            }
        }

        entityManager.getTransaction().commit();
        entityManager.close();
        entityManagerFactory.close();
    }
}
