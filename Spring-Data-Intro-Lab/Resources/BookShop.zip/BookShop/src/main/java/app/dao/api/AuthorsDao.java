package app.dao.api;

import app.domain.Author;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthorsDao extends JpaRepository<Author, Long>{
    Author findByFirstNameOrderByIdDesc(String firstName);

    Author findByFirstNameAndLastName(String firstName, String lastName);
}
