package app.service.impl;

import app.dao.api.AuthorsDao;
import app.domain.Author;
import app.domain.Book;
import app.service.api.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class AuthorServiceImpl implements AuthorService {

    @Autowired
    private AuthorsDao authorsDao;

    @Override
    public List<Book> careerBooks(Author author) {
        return null;
    }

    @Override
    public Book lastBook(Author author) {
        return null;
    }

    @Override
    public String preferredGenre(Author author) {
        return null;
    }

    @Override
    public List<Author> coAuthors(Author author) {
        return null;
    }

    @Override
    public void save(Author author) {
        authorsDao.save(author);
    }

    @Override
    public List<Author> findAll() {
        return authorsDao.findAll();
    }

    @Override
    public void printAuthor(Author author) {
        System.out.println(author);
    }
}
