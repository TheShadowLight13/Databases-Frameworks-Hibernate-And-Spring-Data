package app.service.impl;

import app.dao.api.BooksDao;
import app.domain.Book;
import app.service.api.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class BookServiceImpl implements BookService{

    @Autowired
    private BooksDao booksDao;

    @Override
    public Book bestSellerOfAllTimes() {
        return null;
    }

    @Override
    public List<Book> mostExpensiveBooks(int count) {
        return null;
    }

    @Override
    public Book findBookByTitle(String title) {
        return booksDao.findByTitle(title);
    }
}
