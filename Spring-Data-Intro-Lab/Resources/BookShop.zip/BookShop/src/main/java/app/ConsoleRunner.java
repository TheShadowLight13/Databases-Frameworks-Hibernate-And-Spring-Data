package app;

import app.domain.Author;
import app.domain.Book;
import app.domain.Category;
import app.service.api.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Created by User on 15.7.2017 г..
 */
@Component
public class ConsoleRunner implements CommandLineRunner {

    @Autowired
    private AuthorService authorsService;


    @Override
    public void run(String... strings) throws Exception {
        Author author = new Author("Karl", "Mai");
        Book vinetu1 = new Book("Vinetu 1", author);
        Set<Category> categoties = new HashSet<>();
        categoties.add(new Category("Adventure"));
        categoties.add(new Category("Wild West"));
        categoties.add(new Category("Indians"));
        vinetu1.setCategories(categoties);
        Set<Book> books = new HashSet<>();
        books.add(vinetu1);
        author.setBooksByAuthor(books);
        authorsService.save(author);
        List<Author> authors = authorsService.findAll();
        for (Author a : authors) {
            authorsService.printAuthor(a);
        }
    }
}
