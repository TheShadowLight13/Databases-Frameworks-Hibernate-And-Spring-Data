package app.service.impl;

import app.dao.api.CategoriesDao;
import app.domain.Category;
import app.service.api.CategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoriesDao categoriesDao;


    @Override
    public Category mostLikedCategory() {
        Iterable<Category> categories = categoriesDao.findAll();

        return null;
    }
}
