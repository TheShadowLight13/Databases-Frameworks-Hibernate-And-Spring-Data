package app.dao.api;

import app.domain.Author;
import app.domain.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Service;

/**
 * Created by User on 13.7.2017 г..
 */
@Service
public interface BooksDao extends JpaRepository<Book, Integer> {

    Book findByTitle(String id);

    Book findByAuthor(Author author);
}
