package app.service.api;

import app.domain.Category;

public interface CategoryService {

    Category mostLikedCategory();
}
