package app.service.api;

import app.domain.Author;
import app.domain.Book;

import java.util.List;

public interface AuthorService {
    List<Book> careerBooks(Author author);

    Book lastBook(Author author);

    String preferredGenre(Author author);

    List<Author> coAuthors(Author author);

    void save(Author author);

    List<Author> findAll ();

    void printAuthor (Author author);
}


