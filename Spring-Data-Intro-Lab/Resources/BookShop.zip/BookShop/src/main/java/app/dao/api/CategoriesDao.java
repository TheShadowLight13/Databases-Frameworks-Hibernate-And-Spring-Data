package app.dao.api;

import app.domain.Category;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

/**
 * Created by User on 13.7.2017 г..
 */
@Service
public interface CategoriesDao extends CrudRepository<Category, Integer> {
    Category findByName(String categoryName);
}
