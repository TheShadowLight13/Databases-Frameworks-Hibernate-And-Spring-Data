package app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Created by User on 13.7.2017 г..
 */
@SpringBootApplication
public class BookshopSystem {

    public static void main(String[] args) {
        SpringApplication.run(BookshopSystem.class, args);

    }
}
